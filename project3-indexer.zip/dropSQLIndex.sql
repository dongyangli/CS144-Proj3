ALTER TABLE ItemLocation DROP INDEX Location;
#DROP INDEX sp_index ON ItemLocation;

DROP TABLE IF EXISTS ItemLocation;

