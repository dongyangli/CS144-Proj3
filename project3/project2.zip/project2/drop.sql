DROP TABLE IF EXISTS Bids, ItemCategory, Categories, Items, Sellers, Bidders, Users;

